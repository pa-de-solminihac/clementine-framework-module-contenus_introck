--
-- Table structure for table `clementine_cms_contenu_html_ckeditor`
--

DROP TABLE IF EXISTS `clementine_cms_contenu_html_ckeditor`;
CREATE TABLE `clementine_cms_contenu_html_ckeditor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contenu_html_ckeditor` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
